<?php

namespace App\CustomClass;

use App\Models\Stations\Station;

function price($stationId,$startTime,$endTime)
{
    $dateTimeObject1 = date_create($startTime);
    $dateTimeObject2 = date_create($endTime);

    $difference = date_diff($dateTimeObject1, $dateTimeObject2);
    $minutes = $difference->days * 24 * 60;
    $minutes += $difference->h * 60;
    $minutes += $difference->i;

    $station = Station::find($stationId);
    $stationMin = $station->calculator->minute;
    // $stationkw = $station->calculator->kw;
    $stationprice = $station->calculator->price;

    $price = $minutes * $stationMin * $stationprice;
    return $price;
}
